package com.example.mynavdrawer.ui.about;

import androidx.lifecycle.ViewModel;

public class AboutViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
