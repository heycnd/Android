package com.example.mynavdrawer.ui.stored;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class StoredViewModel  extends ViewModel{




        private MutableLiveData<String> mText;

        public StoredViewModel() {
            mText = new MutableLiveData<>();
            mText.setValue("Here can store money~");
        }

        public LiveData<String> getText() {
            return mText;
        }
    }

